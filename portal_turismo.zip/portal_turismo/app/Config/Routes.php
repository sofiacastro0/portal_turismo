<?php

use CodeIgniter\Router\RouteCollection;

/** @var RouteCollection $routes */
$routes->get('/', 'Home::index');
$routes->get('historia', 'Home::historia');
$routes->get('gastronomia', 'Home::gastronomia');
$routes->get('geografia', 'Home::geografia');
$routes->get('transporte', 'Home::transporte');

$routes->get('registro', 'Auth::registro');
$routes->post('registro', 'Auth::procesarRegistro');
$routes->get('login', 'Auth::login');
$routes->post('login', 'Auth::procesarLogin');
$routes->get('logout', 'Auth::logout');

$routes->group('cliente', ['filter' => 'authUsuario'], function($routes) {
    $routes->get('actividades', 'Catalogo::actividades');
    $routes->get('alojamientos', 'Catalogo::alojamientos');
    $routes->get('detalle/(:num)', 'Catalogo::detalle/$1');
    $routes->post('reservar/(:num)', 'Reservas::crear/$1');
});

$routes->group('cliente', ['filter' => 'authCliente'], function($routes) {
    $routes->get('historial', 'Reservas::historial');
});

// Rutas protegidas súper estrictas para ADMINISTRADORES (usa el filtro authAdmin)
$routes->group('admin', ['filter' => 'authAdmin'], function($routes) {
    $routes->get('publicaciones', 'Admin::index');
    $routes->get('publicaciones/crear', 'Admin::crear');
    $routes->post('publicaciones/guardar', 'Admin::guardar');
    $routes->get('publicaciones/editar/(:num)', 'Admin::editar/$1');
    $routes->post('publicaciones/actualizar/(:num)', 'Admin::actualizar/$1');
    $routes->post('publicaciones/eliminar/(:num)', 'Admin::eliminar/$1');
    $routes->get('reservas', 'Admin::reservas');
    $routes->get('usuarios', 'Admin::usuarios');
    $routes->post('usuarios/eliminar/(:num)', 'Admin::eliminarUsuario/$1');
    $routes->get('imagenes', 'Admin::imagenesPaginas');
    $routes->post('imagenes/(:segment)', 'Admin::guardarImagenPagina/$1');
});
