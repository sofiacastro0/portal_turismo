<?php
namespace App\Models;
use CodeIgniter\Model;

class PublicacionModel extends Model
{
    protected $table      = 'publicaciones';
    protected $primaryKey = 'id_publicacion';

    protected $useAutoIncrement = true;
    protected $returnType     = 'array';

    protected $allowedFields = [
        'id_categoria', 
        'tipo', 
        'nombre', 
        'ubicacion', 
        'cupo_disponible', 
        'precio', 
        'imagen', 
        'temporada_recomendada', 
        'reservas_totales'
    ];
}