<?php
namespace App\Models;
use CodeIgniter\Model;

class ReservaModel extends Model
{
    protected $table      = 'reservas';
    protected $primaryKey = 'id_reserva';

    protected $useAutoIncrement = true;
    protected $returnType     = 'array';

    protected $allowedFields = ['id_usuario', 'id_publicacion', 'cantidad_cupos', 'fecha_reserva'];
}