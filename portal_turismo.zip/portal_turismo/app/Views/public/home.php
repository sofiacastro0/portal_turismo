<?= view('layout/header') ?>

<div class="inicio-page">
    <section class="inicio-encabezado" aria-labelledby="inicio-titulo">
        <p class="inicio-etiqueta">Buenos Aires, Argentina · Costa Atlántica</p>
        <h1 id="inicio-titulo">Descubrí Mar del Plata</h1>
        <p>Mar, cultura y sabores te esperan en uno de los destinos más queridos de la Argentina.</p>
    </section>

    <section class="inicio-propuestas" aria-labelledby="propuestas-titulo">
        <div class="inicio-seccion-titulo">
            <div>
                <p class="inicio-etiqueta">Ideas para tu próxima salida</p>
                <h2 id="propuestas-titulo">Propuestas destacadas <span aria-hidden="true">✦</span></h2>
                <p>Explorá opciones y elegí cómo querés vivir la ciudad.</p>
            </div>
            <a class="inicio-ver-todo" href="<?= site_url('gastronomia') ?>">Explorar la ciudad <span aria-hidden="true">→</span></a>
        </div>

        <?php if (!empty($publicaciones)): ?>
            <div class="inicio-tarjetas">
                <?php foreach ($publicaciones as $pub): ?>
                    <?php $esAlojamiento = $pub['tipo'] === 'alojamiento'; ?>
                    <article class="inicio-tarjeta">
                        <div class="inicio-foto">
                            <?php if (!empty($pub['imagen'])): ?>
                                <img src="<?= base_url('uploads/' . rawurlencode($pub['imagen'])) ?>" alt="<?= esc($pub['nombre']) ?>" loading="lazy">
                            <?php else: ?>
                                <div class="inicio-foto-vacia" aria-hidden="true">📍</div>
                            <?php endif; ?>
                            <span class="inicio-badge"><?= $esAlojamiento ? 'ALOJAMIENTO' : 'ACTIVIDAD' ?></span>
                        </div>
                        <div class="inicio-detalle">
                            <p class="inicio-destino"><?= $esAlojamiento ? 'PARA DESCANSAR' : 'PARA DISFRUTAR' ?></p>
                            <h3><?= esc($pub['nombre']) ?></h3>
                            <p class="inicio-ubicacion"><span aria-hidden="true">⌖</span> <?= esc($pub['ubicacion']) ?></p>

                            <div class="inicio-datos">
                                <div class="inicio-dato">
                                    <span aria-hidden="true">◷</span>
                                    <span><small>DISPONIBILIDAD</small><strong><?= (int) $pub['cupo_disponible'] > 0 ? esc($pub['cupo_disponible']) . ' cupos' : 'Consultar' ?></strong></span>
                                </div>
                                <div class="inicio-dato">
                                    <span aria-hidden="true">$</span>
                                    <span><small><?= $esAlojamiento ? 'DESDE' : 'PRECIO' ?></small><strong>$<?= esc($pub['precio']) ?><?= $esAlojamiento ? ' / noche' : '' ?></strong></span>
                                </div>
                            </div>

                            <a class="inicio-boton" href="<?= site_url('cliente/detalle/' . (int) $pub['id_publicacion']) ?>">Ver propuesta <span aria-hidden="true">→</span></a>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="inicio-vacio">
                <span aria-hidden="true">🌿</span>
                <h3>Muy pronto vas a encontrar propuestas acá</h3>
                <p>Mientras tanto, descubrí la historia, los sabores y los paisajes de Mar del Plata.</p>
                <a class="inicio-boton" href="<?= site_url('gastronomia') ?>">Conocer la ciudad <span aria-hidden="true">→</span></a>
            </div>
        <?php endif; ?>
    </section>

    <nav class="inicio-accesos" aria-label="Explorá Mar del Plata">
        <a href="<?= site_url('historia') ?>"><span class="inicio-acceso-icono" aria-hidden="true">⌂</span><span><small>CONOCÉ</small><strong>Historia y patrimonio</strong></span><span class="inicio-flecha" aria-hidden="true">→</span></a>
        <a href="<?= site_url('gastronomia') ?>"><span class="inicio-acceso-icono" aria-hidden="true">☕</span><span><small>DISFRUTÁ</small><strong>Gastronomía y actividades</strong></span><span class="inicio-flecha" aria-hidden="true">→</span></a>
        <a href="<?= site_url('transporte') ?>"><span class="inicio-acceso-icono" aria-hidden="true">↗</span><span><small>PLANIFICÁ</small><strong>Cómo llegar</strong></span><span class="inicio-flecha" aria-hidden="true">→</span></a>
    </nav>
</div>

<?= view('layout/footer') ?>
