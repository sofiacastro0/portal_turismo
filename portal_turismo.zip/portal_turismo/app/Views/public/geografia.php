<?= view('layout/header') ?>

<article class="destino-page">
    <header class="destino-hero"<?php if (! empty($imagenFondo)): ?> style="--destino-hero-imagen: url('<?= esc(base_url('uploads/paginas/' . rawurlencode($imagenFondo)), 'attr') ?>')"<?php endif; ?>>
        <p class="destino-kicker">Costa Atlántica · Provincia de Buenos Aires</p>
        <h1>Mar, sierras y paisajes abiertos</h1>
        <p>Mar del Plata está en el sudeste bonaerense, a orillas del océano Atlántico, dentro del partido de General Pueyrredon.</p>
    </header>

    <section class="destino-stats" aria-label="Características del destino">
        <article><strong>47 km</strong><span>de costa con playas y acantilados</span></article>
        <article><strong>Atlántico</strong><span>clima templado con influencia marítima</span></article>
        <article><strong>Todo el año</strong><span>propuestas de mar, cultura y naturaleza</span></article>
    </section>

    <section class="destino-panel destino-panel-split" aria-labelledby="paisajes-titulo">
        <div>
            <p class="destino-kicker">Un entorno diverso</p>
            <h2 id="paisajes-titulo">Mucho más que playa</h2>
            <p>A lo largo de la costa se alternan bahías, playas, acantilados y sectores de bosque. Hacia el interior aparecen sierras, lagunas, arroyos y paisajes rurales, como los alrededores de Sierra de los Padres.</p>
        </div>
        <div class="destino-clima">
            <h3>Clima y estaciones</h3>
            <p>La influencia del mar hace que el tiempo pueda cambiar durante el día. El verano invita a disfrutar de la playa; otoño y primavera son ideales para paseos al aire libre, y en invierno conviene llevar abrigo y prepararse para días frescos y ventosos.</p>
        </div>
    </section>
</article>

<?= view('layout/footer') ?>
