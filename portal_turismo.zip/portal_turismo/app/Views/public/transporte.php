<?= view('layout/header') ?>

<article class="destino-page">
    <header class="destino-hero">
        <p class="destino-kicker">Información práctica</p>
        <h1>Cómo llegar a Mar del Plata</h1>
        <p>La ciudad está conectada con distintos puntos del país por rutas, trenes, micros de larga distancia y vuelos.</p>
    </header>

    <section class="transporte-layout" aria-label="Cómo llegar y ubicar Mar del Plata">
        <div class="transporte-metodos">
            <div class="destino-section-heading">
                <p class="destino-kicker">Elegí cómo viajar</p>
                <h2>Opciones de transporte</h2>
            </div>
            <div class="transporte-lista">
                <article class="destino-card transporte-card">
                    <span class="destino-card-emoji" aria-hidden="true">🚗</span>
                    <div><p class="destino-kicker">Por ruta</p><h3>En auto</h3><p>Desde la Ciudad de Buenos Aires, la Autovía 2 es uno de los principales accesos. Las rutas provinciales 11, 88 y 226 también conectan Mar del Plata con otras localidades.</p></div>
                </article>
                <article class="destino-card transporte-card">
                    <span class="destino-card-emoji" aria-hidden="true">🚆</span>
                    <div><p class="destino-kicker">Conexión ferroviaria</p><h3>En tren</h3><p>Los servicios ferroviarios de larga distancia llegan a la estación terminal ferroautomotora. Consultá horarios y disponibilidad antes de viajar.</p></div>
                </article>
                <article class="destino-card transporte-card">
                    <span class="destino-card-emoji" aria-hidden="true">🚌</span>
                    <div><p class="destino-kicker">Larga distancia</p><h3>En micro</h3><p>La terminal ferroautomotora recibe servicios de ómnibus desde Buenos Aires y distintos destinos del país.</p></div>
                </article>
                <article class="destino-card transporte-card">
                    <span class="destino-card-emoji" aria-hidden="true">✈️</span>
                    <div><p class="destino-kicker">Conexión aérea</p><h3>En avión</h3><p>El Aeropuerto Internacional Ástor Piazzolla conecta la ciudad con vuelos de cabotaje. La disponibilidad de rutas puede variar según la temporada.</p></div>
                </article>
            </div>
        </div>

        <aside class="transporte-mapa" aria-labelledby="mapa-titulo">
            <div class="transporte-mapa-heading">
                <div><p class="destino-kicker">Costa Atlántica</p><h2 id="mapa-titulo">Encontrá Mar del Plata</h2></div>
                <span aria-hidden="true">⌖</span>
            </div>
            <iframe
                title="Mapa de Mar del Plata, Buenos Aires, Argentina en Google Maps"
                src="https://maps.google.com/maps?q=Mar%20del%20Plata%2C%20Buenos%20Aires%2C%20Argentina&amp;z=12&amp;output=embed"
                loading="lazy"
                referrerpolicy="no-referrer-when-downgrade"
                allowfullscreen>
            </iframe>
            <a class="transporte-mapa-link" href="https://www.google.com/maps/search/?api=1&amp;query=Mar%20del%20Plata%2C%20Buenos%20Aires%2C%20Argentina" target="_blank" rel="noopener noreferrer">Abrir mapa en Google Maps <span aria-hidden="true">↗</span></a>
        </aside>
    </section>

    <section class="destino-cta">
        <div>
            <p class="destino-kicker">Organizá tu visita</p>
            <h2>Encontrá actividades y alojamientos</h2>
            <p><?= session()->get('logeado') ? 'Consultá las propuestas disponibles en el portal.' : 'Creá una cuenta para consultar las propuestas disponibles en el portal.' ?></p>
        </div>
        <?php if (session()->get('logeado')): ?>
            <a href="<?= site_url('cliente/actividades') ?>">Explorar propuestas <span aria-hidden="true">→</span></a>
        <?php else: ?>
            <a href="<?= site_url('registro') ?>">Crear cuenta <span aria-hidden="true">→</span></a>
        <?php endif; ?>
    </section>
</article>

<?= view('layout/footer') ?>
