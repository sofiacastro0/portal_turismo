<?= view('layout/header') ?>

<article class="destino-page">
    <header class="destino-hero"<?php if (! empty($imagenFondo)): ?> style="--destino-hero-imagen: url('<?= esc(base_url('uploads/paginas/' . rawurlencode($imagenFondo)), 'attr') ?>')"<?php endif; ?>>
        <p class="destino-kicker">Sabores de la Costa Atlántica</p>
        <h1>Una ciudad para saborear</h1>
        <p>La cocina de mar, los clásicos de cafetería y los dulces marplatenses forman parte de la experiencia.</p>
    </header>

    <section class="destino-grid" aria-label="Sabores y actividades de Mar del Plata">
        <article class="destino-card destino-card-feature">
            <span class="destino-card-emoji" aria-hidden="true">⚓</span>
            <p class="destino-kicker">Un clásico del puerto</p>
            <h2>Pescados y frutos de mar</h2>
            <p>En la zona del puerto podés probar platos preparados con pesca local y recorrer la banquina entre barcos, sabores y postales marineras.</p>
        </article>
        <article class="destino-card">
            <span class="destino-card-emoji" aria-hidden="true">☕</span>
            <p class="destino-kicker">Pausa dulce</p>
            <h2>Churros y medialunas</h2>
            <p>Una merienda frente al mar, churros recién hechos y medialunas son parte de los gustos clásicos de la ciudad.</p>
        </article>
        <article class="destino-card">
            <span class="destino-card-emoji" aria-hidden="true">🍬</span>
            <p class="destino-kicker">Para llevar</p>
            <h2>Alfajores marplatenses</h2>
            <p>Las confiterías y fábricas locales ofrecen distintas versiones de uno de los dulces más asociados con Mar del Plata.</p>
        </article>
        <article class="destino-card">
            <span class="destino-card-emoji" aria-hidden="true">✦</span>
            <p class="destino-kicker">Planes para la tarde y la noche</p>
            <h2>Cervecerías, cafés y teatros</h2>
            <p>La agenda suma cafeterías, cervecerías artesanales, espectáculos, museos y paseos por la costa para combinar con cualquier temporada.</p>
        </article>
    </section>
</article>

<?= view('layout/footer') ?>
