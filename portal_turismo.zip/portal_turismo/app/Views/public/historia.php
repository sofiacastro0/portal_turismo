<?= view('layout/header') ?>

<article class="destino-page">
    <header class="destino-hero"<?php if (! empty($imagenFondo)): ?> style="--destino-hero-imagen: url('<?= esc(base_url('uploads/paginas/' . rawurlencode($imagenFondo)), 'attr') ?>')"<?php endif; ?>>
        <p class="destino-kicker">Mar del Plata · Buenos Aires, Argentina</p>
        <h1>Una ciudad con historia junto al mar</h1>
        <p>Del antiguo asentamiento costero a uno de los grandes destinos turísticos del país.</p>
    </header>

    <section class="destino-panel" aria-labelledby="historia-origen">
        <div class="destino-panel-icon" aria-hidden="true">⌂</div>
        <div>
            <p class="destino-kicker">Los comienzos</p>
            <h2 id="historia-origen">De Puerto de Laguna de los Padres a Mar del Plata</h2>
            <p>La ciudad fue fundada por Patricio Peralta Ramos el 10 de febrero de 1874. El primer tren llegó en 1886 y ayudó a conectar la costa con Buenos Aires, impulsando el crecimiento de la ciudad y sus primeros años como destino de descanso.</p>
        </div>
    </section>

    <section class="destino-section" aria-labelledby="historia-lugares">
        <div class="destino-section-heading">
            <p class="destino-kicker">Recorridos para conocerla</p>
            <h2 id="historia-lugares">Postales históricas</h2>
        </div>
        <div class="destino-grid">
            <article class="destino-card"><span class="destino-card-number">01</span><h3>La Rambla y el Casino Central</h3><p>Un paseo emblemático frente al mar, junto al Hotel Provincial y las esculturas de los lobos marinos.</p></article>
            <article class="destino-card"><span class="destino-card-number">02</span><h3>Capilla Santa Cecilia</h3><p>Construida en 1873, es uno de los edificios históricos vinculados a los primeros años de la ciudad.</p></article>
            <article class="destino-card"><span class="destino-card-number">03</span><h3>Torreón del Monje</h3><p>Una construcción característica sobre la costa, con vistas al mar y una silueta reconocible de Mar del Plata.</p></article>
            <article class="destino-card"><span class="destino-card-number">04</span><h3>Villa Victoria</h3><p>La antigua residencia de Victoria Ocampo permite acercarse a la vida cultural y arquitectónica de otra época.</p></article>
        </div>
    </section>
</article>

<?= view('layout/footer') ?>
