<!DOCTYPE html>
<html lang="es" data-bs-theme="light">
<head>
    <title>Panel de Administrador</title>
    <?= view('layout/bootstrap_head') ?>
</head>
<body>
    <?= view('layout/navbar') ?>
    <main class="container py-4">
    <h2>Gestión de Actividades y Alojamientos</h2>

    <?php if ($error = session()->getFlashdata('error')): ?>
        <div class="alert alert-danger" role="alert"><?= esc($error) ?></div>
    <?php endif; ?>
    
    <a href="<?= base_url('admin/publicaciones/crear') ?>">+ Cargar Nueva Publicación</a>
    <br><br>

    <table border="1" cellpadding="10" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>Imagen</th>
                <th>Nombre</th>
                <th>Ubicación</th>
                <th>Tipo</th>
                <th>Cupo</th>
                <th>Precio</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php if(!empty($publicaciones)): ?>
                <?php foreach($publicaciones as $pub): ?>
                    <tr>
                        <td><img src="<?= base_url('uploads/' . esc($pub['imagen'])) ?>" width="80" alt="Foto"></td>
                        <td><?= esc($pub['nombre']) ?></td>
                        <td><?= esc($pub['ubicacion']) ?></td>
                        <td><?= esc($pub['tipo']) ?></td>
                        <td><?= esc($pub['cupo_disponible']) ?></td>
                        <td>$<?= esc($pub['precio']) ?></td>
                        <td>
                            <!-- Botón para Editar -->
                            <a href="<?= base_url('admin/publicaciones/editar/'.$pub['id_publicacion']) ?>">Editar</a>
                            
                            <!-- Botón para Eliminar -->
                            <form class="d-inline" method="post" action="<?= site_url('admin/publicaciones/eliminar/' . $pub['id_publicacion']) ?>" onsubmit="return confirm('¿Seguro que deseas eliminar esto?');">
                                <button class="btn btn-link p-0" type="submit">Eliminar</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="7">No hay publicaciones cargadas.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
    </main>

    <?= view('layout/bootstrap_script') ?>
</body>
</html>
