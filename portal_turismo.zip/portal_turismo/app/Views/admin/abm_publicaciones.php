<!DOCTYPE html>
<html lang="es" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <title><?= isset($publicacion) ? 'Editar' : 'Cargar' ?> Publicación</title>
    <?= view('layout/bootstrap_head') ?>
</head>
<body>
    <?= view('layout/navbar') ?>
    <main class="container py-4">
    <h2><?= isset($publicacion) ? 'Editar' : 'Cargar nueva' ?> Actividad o Alojamiento</h2>
    <?php if ($error = session()->getFlashdata('error')): ?>
        <div class="alert alert-danger" role="alert"><?= esc($error) ?></div>
    <?php endif; ?>
    <?php if ($errores = session()->getFlashdata('errors')): ?>
        <div class="alert alert-danger" role="alert"><ul class="mb-0"><?php foreach ($errores as $error): ?><li><?= esc($error) ?></li><?php endforeach; ?></ul></div>
    <?php endif; ?>
    <a href="<?= base_url('admin/publicaciones') ?>">⬅ Volver al listado</a><br><br>

    <?php $accion = isset($publicacion) ? base_url('admin/publicaciones/actualizar/'.$publicacion['id_publicacion']) : base_url('admin/publicaciones/guardar'); ?>
    
    <form action="<?= $accion ?>" method="POST" enctype="multipart/form-data">
        
        <label>Nombre:</label>
        <input type="text" name="nombre" value="<?= isset($publicacion) ? esc($publicacion['nombre']) : '' ?>" required><br><br>

        <label>Ubicación (Región, ciudad o pueblo):</label>
        <input type="text" name="ubicacion" value="<?= isset($publicacion) ? esc($publicacion['ubicacion']) : '' ?>" required><br><br>

        <label>Categoría:</label>
        <select name="id_categoria" required>
            <option value="">Seleccione...</option>
            <?php foreach($categorias as $cat): ?>
                <option value="<?= $cat['id_categoria'] ?>" 
                    <?= (isset($publicacion) && $publicacion['id_categoria'] == $cat['id_categoria']) ? 'selected' : '' ?>>
                    <?= esc($cat['nombre']) ?>
                </option>
            <?php endforeach; ?>
        </select><br><br>

        <label>Tipo:</label>
        <select name="tipo" required>
            <option value="actividad" <?= (isset($publicacion) && $publicacion['tipo'] == 'actividad') ? 'selected' : '' ?>>Actividad</option>
            <option value="alojamiento" <?= (isset($publicacion) && $publicacion['tipo'] == 'alojamiento') ? 'selected' : '' ?>>Alojamiento</option>
        </select><br><br>

        <label>Temporada Recomendada:</label>
        <select name="temporada_recomendada">
            <option value="todas" <?= (isset($publicacion) && $publicacion['temporada_recomendada'] == 'todas') ? 'selected' : '' ?>>Todo el año</option>
            <option value="verano" <?= (isset($publicacion) && $publicacion['temporada_recomendada'] == 'verano') ? 'selected' : '' ?>>Verano</option>
            <option value="otoño" <?= (isset($publicacion) && $publicacion['temporada_recomendada'] == 'otoño') ? 'selected' : '' ?>>Otoño</option>
            <option value="invierno" <?= (isset($publicacion) && $publicacion['temporada_recomendada'] == 'invierno') ? 'selected' : '' ?>>Invierno</option>
            <option value="primavera" <?= (isset($publicacion) && $publicacion['temporada_recomendada'] == 'primavera') ? 'selected' : '' ?>>Primavera</option>
        </select><br><br>

        <label>Cupo Disponible:</label>
        <input type="number" name="cupo_disponible" min="0" value="<?= isset($publicacion) ? esc($publicacion['cupo_disponible']) : '' ?>" required><br><br>

        <label>Precio ($):</label>
        <input type="number" name="precio" step="0.01" value="<?= isset($publicacion) ? esc($publicacion['precio']) : '' ?>" required><br><br>

        <label>Imagen ilustrativa:</label>
        <?php if(isset($publicacion)): ?>
            <br>
            <img src="<?= base_url('uploads/' . $publicacion['imagen']) ?>" width="100" alt="Foto actual"><br>
            <small>Deje este campo vacío si no desea cambiar la foto.</small><br>
        <?php endif; ?>
        
        <input type="file" name="imagen" accept="image/*" <?= isset($publicacion) ? '' : 'required' ?>><br><br>

        <button type="submit"><?= isset($publicacion) ? 'Actualizar' : 'Guardar' ?> Publicación</button>
    </form>
    </main>
    <?= view('layout/bootstrap_script') ?>
</body>
</html>
