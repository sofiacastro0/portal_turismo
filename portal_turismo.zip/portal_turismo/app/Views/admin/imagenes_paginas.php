<!DOCTYPE html>
<html lang="es" data-bs-theme="light">
<head>
    <title>Imágenes de páginas | Administración</title>
    <?= view('layout/bootstrap_head') ?>
</head>
<body class="bg-body-tertiary">
    <?= view('layout/navbar') ?>
    <main class="container py-4 admin-imagenes">
        <header class="mb-4">
            <p class="text-body-secondary mb-1">Administración</p>
            <h1 class="h2 mb-2">Imágenes de las páginas</h1>
            <p class="text-body-secondary">Subí una imagen para el fondo azul de cada sección. Al reemplazarla, solo se conserva la nueva.</p>
        </header>

        <?php if ($error = session()->getFlashdata('error')): ?>
            <div class="alert alert-danger" role="alert"><?= esc($error) ?></div>
        <?php endif; ?>
        <?php if ($mensaje = session()->getFlashdata('mensaje')): ?>
            <div class="alert alert-success" role="status"><?= esc($mensaje) ?></div>
        <?php endif; ?>

        <div class="admin-imagenes-grid">
            <?php foreach ($paginas as $slug => $titulo): ?>
                <section class="admin-imagen-card">
                    <div class="admin-imagen-preview">
                        <?php if (!empty($imagenes[$slug])): ?>
                            <img src="<?= base_url('uploads/paginas/' . rawurlencode($imagenes[$slug])) ?>" alt="Imagen actual de <?= esc($titulo) ?>">
                            <span>Imagen actual</span>
                        <?php else: ?>
                            <div class="admin-imagen-vacia">Todavía no hay una imagen</div>
                        <?php endif; ?>
                    </div>
                    <div class="admin-imagen-content">
                        <p class="text-uppercase text-primary small fw-bold">Fondo del encabezado</p>
                        <h2><?= esc($titulo) ?></h2>
                        <form method="post" enctype="multipart/form-data" action="<?= site_url('admin/imagenes/' . $slug) ?>">
                            <?= csrf_field() ?>
                            <label for="imagen-<?= esc($slug) ?>">Elegí una imagen (máximo 4 MB)</label>
                            <input class="form-control" type="file" id="imagen-<?= esc($slug) ?>" name="imagen" accept="image/jpeg,image/png,image/webp,image/gif" required>
                            <button class="btn btn-primary mt-3" type="submit">Guardar imagen</button>
                        </form>
                    </div>
                </section>
            <?php endforeach; ?>
        </div>
    </main>
    <?= view('layout/bootstrap_script') ?>
</body>
</html>
