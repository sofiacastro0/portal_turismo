<!DOCTYPE html>
<html lang="es" data-bs-theme="light">
<head>
    <title>Usuarios | Administración</title>
    <?= view('layout/bootstrap_head') ?>
</head>
<body>
    <?= view('layout/navbar') ?>
    <main class="container py-4">
        <div class="d-flex flex-column flex-sm-row justify-content-between align-items-sm-center gap-2 mb-4">
            <div>
                <p class="text-body-secondary mb-1">Administración</p>
                <h1 class="h2 mb-0">Cuentas registradas</h1>
            </div>
            <span class="badge text-bg-secondary"><?= count($usuarios) ?> cuentas</span>
        </div>

        <?php if ($error = session()->getFlashdata('error')): ?>
            <div class="alert alert-danger" role="alert"><?= esc($error) ?></div>
        <?php endif; ?>
        <?php if ($mensaje = session()->getFlashdata('mensaje')): ?>
            <div class="alert alert-success" role="status"><?= esc($mensaje) ?></div>
        <?php endif; ?>

        <div class="table-responsive rounded-3 border bg-body">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Nombre completo</th>
                        <th scope="col">Correo electrónico</th>
                        <th scope="col">Rol</th>
                        <th scope="col" class="text-end">Acción</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($usuarios)): ?>
                        <?php foreach ($usuarios as $usu): ?>
                            <tr>
                                <td><?= esc($usu['id_usuario']) ?></td>
                                <td><?= esc($usu['nombre']) ?></td>
                                <td><?= esc($usu['email']) ?></td>
                                <td><span class="badge text-bg-light border"><?= esc(strtoupper($usu['rol'])) ?></span></td>
                                <td class="text-end">
                                    <?php if ((int) $usu['id_usuario'] === (int) session()->get('id_usuario')): ?>
                                        <span class="text-body-secondary small">Tu cuenta</span>
                                    <?php else: ?>
                                        <form method="post" action="<?= site_url('admin/usuarios/eliminar/' . (int) $usu['id_usuario']) ?>" onsubmit="return confirm('¿Eliminar la cuenta de <?= esc($usu['nombre'], 'js') ?>? También se eliminarán sus reservas asociadas.');">
                                            <?= csrf_field() ?>
                                            <button class="btn btn-sm btn-outline-danger" type="submit">Eliminar cuenta</button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="5" class="py-4 text-center text-body-secondary">No hay cuentas registradas.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>
    <?= view('layout/bootstrap_script') ?>
</body>
</html>
