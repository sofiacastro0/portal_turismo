<!DOCTYPE html>
<html lang="es" data-bs-theme="light">
<head>
    <title>Consulta de Reservas</title>
    <?= view('layout/bootstrap_head') ?>
</head>
<body>
    <?= view('layout/navbar') ?>
    <main class="container py-4">
    <h2>Listado General de Reservas</h2>

    <table border="1" cellpadding="10" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>Fecha</th>
                <th>Cliente</th>
                <th>Email Contacto</th>
                <th>Actividad / Alojamiento</th>
                <th>Cupos</th>
                <th>Monto Total</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($reservas)): ?>
                <?php foreach ($reservas as $res): ?>
                    <tr>
                        <td><?= date('d/m/Y H:i', strtotime($res['fecha_reserva'])) ?></td>
                        <td><?= esc($res['nombre_usuario']) ?></td>
                        <td><?= esc($res['email']) ?></td>
                        <td><?= esc($res['nombre_publicacion']) ?></td>
                        <td><?= esc($res['cantidad_cupos']) ?></td>
                        <td>$<?= number_format($res['cantidad_cupos'] * $res['precio'], 2, ',', '.') ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="6">No hay reservas registradas en el sistema.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
    </main>
    <?= view('layout/bootstrap_script') ?>
</body>
</html>
