<?= view('layout/header') ?>

<section class="registro-shell" aria-labelledby="registro-titulo">
    <div class="registro-card">
        <header class="registro-header">
            <p class="registro-eyebrow">Turismo Mar del Plata · Buenos Aires, Argentina</p>
            <h1 id="registro-titulo">Crear cuenta</h1>
            <p>Registrate para reservar actividades y alojamientos.</p>
        </header>

        <?php if ($error = session()->getFlashdata('error')): ?>
            <div class="registro-alert" role="alert"><?= esc($error) ?></div>
        <?php endif; ?>
        <?php $errores = session()->getFlashdata('errors') ?? []; ?>

        <form class="registro-form" id="formRegistro" method="post" action="<?= site_url('registro') ?>" novalidate>
            <?= csrf_field() ?>
            <div class="registro-campo">
                <label for="registroNombre">Nombre completo</label>
                <input class="registro-input<?= isset($errores['nombre']) ? ' is-invalid' : '' ?>" type="text" id="registroNombre" name="nombre" value="<?= esc(old('nombre') ?? '') ?>" placeholder="Tu nombre" autocomplete="name" minlength="2" maxlength="100" required aria-describedby="errorNombre">
                <small class="registro-error" id="errorNombre"><?= esc($errores['nombre'] ?? '') ?></small>
            </div>
            <div class="registro-campo">
                <label for="registroEmail">Correo electrónico</label>
                <input class="registro-input<?= isset($errores['email']) ? ' is-invalid' : '' ?>" type="email" id="registroEmail" name="email" value="<?= esc(old('email') ?? '') ?>" placeholder="nombre@ejemplo.com" autocomplete="email" maxlength="254" required aria-describedby="errorEmail">
                <small class="registro-error" id="errorEmail"><?= esc($errores['email'] ?? '') ?></small>
            </div>
            <div class="registro-campo">
                <label for="registroPassword">Contraseña</label>
                <input class="registro-input<?= isset($errores['password']) ? ' is-invalid' : '' ?>" type="password" id="registroPassword" name="password" placeholder="Mínimo 8 caracteres" autocomplete="new-password" minlength="8" maxlength="255" aria-describedby="registro-ayuda errorPassword" required>
                <small id="registro-ayuda">Usá al menos 8 caracteres.</small>
                <small class="registro-error" id="errorPassword"><?= esc($errores['password'] ?? '') ?></small>
            </div>
            <button class="registro-submit" type="submit">Crear cuenta</button>
        </form>

        <p class="registro-login">¿Ya tenés una cuenta? <a href="<?= site_url('login') ?>">Iniciá sesión</a></p>
    </div>
</section>

<script>
(() => {
    const formulario = document.getElementById('formRegistro');
    const mensajes = {
        valueMissing: 'Completá este campo.',
        typeMismatch: 'Ingresá un correo electrónico válido.',
        tooLong: 'El valor es demasiado largo.',
        patternMismatch: 'Revisá el formato ingresado.'
    };

    formulario.querySelectorAll('input').forEach((campo) => {
        campo.addEventListener('invalid', () => {
            const estado = campo.validity;
            const clave = estado.valueMissing ? 'valueMissing'
                : estado.typeMismatch ? 'typeMismatch'
                : estado.tooShort ? 'tooShort'
                : estado.tooLong ? 'tooLong'
                : estado.patternMismatch ? 'patternMismatch' : null;
            const mensaje = clave === 'tooShort'
                ? (campo.type === 'password' ? 'La contraseña debe tener al menos 8 caracteres.' : 'El nombre debe tener al menos 2 caracteres.')
                : (clave ? mensajes[clave] : 'Revisá este dato.');
            campo.setCustomValidity(mensaje);
        });
        campo.addEventListener('input', () => campo.setCustomValidity(''));
    });

    formulario.addEventListener('submit', (evento) => {
        if (!formulario.checkValidity()) {
            evento.preventDefault();
            formulario.reportValidity();
        }
    });
})();
</script>

<?= view('layout/footer') ?>
