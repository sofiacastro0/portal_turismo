<?= view('layout/header') ?>

<section class="registro-shell" aria-labelledby="login-titulo">
    <div class="registro-card">
        <header class="registro-header">
            <p class="registro-eyebrow">Turismo Mar del Plata · Buenos Aires, Argentina</p>
            <h1 id="login-titulo">Iniciar sesión</h1>
            <p>Ingresá a tu cuenta para continuar.</p>
        </header>

        <?php if ($mensaje = session()->getFlashdata('mensaje')): ?>
            <div class="login-success" role="status"><?= esc($mensaje) ?></div>
        <?php endif; ?>
        <?php $errores = session()->getFlashdata('errors') ?? []; ?>

        <form class="registro-form" method="post" action="<?= site_url('login') ?>">
            <?= csrf_field() ?>
            <div class="registro-campo">
                <label for="loginEmail">Correo electrónico</label>
                <input class="registro-input<?= isset($errores['email']) ? ' is-invalid' : '' ?>" type="email" id="loginEmail" name="email" value="<?= esc(old('email') ?? '') ?>" placeholder="nombre@ejemplo.com" autocomplete="email" maxlength="254" required aria-describedby="loginEmailError">
                <small class="registro-error" id="loginEmailError"><?= esc($errores['email'] ?? '') ?></small>
            </div>
            <div class="registro-campo">
                <label for="loginPassword">Contraseña</label>
                <input class="registro-input<?= isset($errores['password']) ? ' is-invalid' : '' ?>" type="password" id="loginPassword" name="password" placeholder="Tu contraseña" autocomplete="current-password" required aria-describedby="loginPasswordError">
                <small class="registro-error" id="loginPasswordError"><?= esc($errores['password'] ?? '') ?></small>
            </div>
            <button class="registro-submit" type="submit">Ingresar</button>
        </form>

        <p class="registro-login">¿No tenés cuenta? <a href="<?= site_url('registro') ?>">Registrate</a></p>
    </div>
</section>

<?= view('layout/footer') ?>
