<?php
$rutaActual = trim(uri_string(), '/');
$enlacesNav = [
    ['Inicio', '/', '/'],
    ['Historia', 'historia', 'historia'],
    ['Geografía', 'geografia', 'geografia'],
    ['Gastronomía', 'gastronomia', 'gastronomia'],
    ['Cómo llegar', 'transporte', 'transporte'],
];

if (session()->get('logeado')) {
    if (session()->get('rol') === 'admin') {
        $enlacesNav = array_merge($enlacesNav, [
            ['Vista cliente', 'cliente/actividades', 'cliente/actividades'],
            ['Publicaciones', 'admin/publicaciones', 'admin/publicaciones'],
            ['Reservas', 'admin/reservas', 'admin/reservas'],
            ['Usuarios', 'admin/usuarios', 'admin/usuarios'],
            ['Imágenes', 'admin/imagenes', 'admin/imagenes'],
        ]);
    } else {
        $enlacesNav = array_merge($enlacesNav, [
            ['Actividades', 'cliente/actividades', 'cliente/actividades'],
            ['Alojamientos', 'cliente/alojamientos', 'cliente/alojamientos'],
            ['Mis reservas', 'cliente/historial', 'cliente/historial'],
        ]);
    }
}
?>
<nav class="navbar sm:navbar-expand bg-1 fg-2 site-navbar" aria-label="Navegación principal">
    <div class="container-fluid site-navbar-inner">
        <a class="navbar-brand site-brand" href="<?= site_url('/') ?>" aria-label="Turismo Mar del Plata, inicio">
            <span class="site-brand-mark" aria-hidden="true">TL</span>
            <span class="site-brand-copy"><strong>Turismo</strong><small>MAR DEL PLATA</small></span>
        </a>

        <button class="btn-icon navbar-toggler site-menu-toggle" type="button" data-bs-toggle="drawer" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Abrir menú">
            <span class="site-menu-lines" aria-hidden="true"><i></i><i></i><i></i></span>
        </button>

        <dialog class="drawer drawer-end site-menu" tabindex="-1" id="navbarNavAltMarkup" aria-labelledby="navbarNavAltMarkupLabel">
            <div class="drawer-header site-menu-header">
                <div>
                    <p class="site-menu-kicker">Portal de Turismo</p>
                    <h2 class="drawer-title" id="navbarNavAltMarkupLabel">Explorá Mar del Plata</h2>
                </div>
                <button type="button" class="btn-close site-menu-close" data-bs-dismiss="drawer" aria-label="Cerrar menú"></button>
            </div>
            <div class="drawer-body site-menu-body">
                <div class="nav nav-pills navbar-nav site-nav-links">
                    <?php foreach ($enlacesNav as [$texto, $ruta, $coincidencia]): ?>
                        <?php
                        $activo = $ruta === '/'
                            ? $rutaActual === ''
                            : ($rutaActual === $coincidencia || str_starts_with($rutaActual, $coincidencia . '/'));
                        ?>
                        <a class="nav-link site-nav-link<?= $activo ? ' active' : '' ?>"<?= $activo ? ' aria-current="page"' : '' ?> href="<?= site_url($ruta) ?>"><?= esc($texto) ?></a>
                    <?php endforeach; ?>
                </div>

                <div class="site-nav-account">
                    <?php if (session()->get('logeado')): ?>
                        <span class="site-user-name"><span class="site-user-avatar" aria-hidden="true"><?= esc(mb_strtoupper(mb_substr((string) session()->get('nombre'), 0, 1))) ?></span>Hola, <?= esc(session()->get('nombre')) ?></span>
                        <a class="site-nav-account-link" href="<?= site_url('logout') ?>">Cerrar sesión</a>
                    <?php else: ?>
                        <a class="site-nav-account-link<?= $rutaActual === 'login' ? ' current' : '' ?>" href="<?= site_url('login') ?>">Iniciar sesión</a>
                        <a class="site-nav-register<?= $rutaActual === 'registro' ? ' current' : '' ?>" href="<?= site_url('registro') ?>">Crear cuenta <span aria-hidden="true">→</span></a>
                    <?php endif; ?>
                </div>
            </div>
        </dialog>
    </div>
</nav>
