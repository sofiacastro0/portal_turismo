    </main>
    <footer class="container-fluid border-top mt-4 py-4">
        <div class="container d-flex flex-wrap justify-content-between gap-3">
            <p class="mb-0">&copy; <?= date('Y') ?> Turismo Mar del Plata · Buenos Aires, Argentina.</p>
            <nav aria-label="Enlaces del pie de página">
                <a href="<?= site_url('historia') ?>">Historia</a>
                <span aria-hidden="true"> · </span>
                <a href="<?= site_url('gastronomia') ?>">Qué hacer</a>
                <span aria-hidden="true"> · </span>
                <a href="<?= site_url('transporte') ?>">Cómo llegar</a>
            </nav>
        </div>
    </footer>
    <?= view('layout/bootstrap_script') ?>
</body>
</html>
