<!DOCTYPE html>
<html lang="es" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <title>Turismo Mar del Plata | Buenos Aires, Argentina</title>
    <?= view('layout/bootstrap_head') ?>
    <link rel="stylesheet" href="<?= base_url('assets/css/registro.css') ?>">
    <link rel="stylesheet" href="<?= base_url('assets/css/inicio.css') ?>">
</head>
<body>
    <?= view('layout/navbar') ?>
    <main class="container-fluid px-3 px-lg-4 py-3">
