<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@6.0.0-alpha.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-B/GM4XqrwHnWXNOWMbloTmrYXZg10cakYGmpfsR/bbzQ6JAJI4ihuyADKLnBgrCe" crossorigin="anonymous">
<link rel="stylesheet" href="<?= base_url('assets/css/navbar.css') ?>">
<link rel="stylesheet" href="<?= base_url('assets/css/cliente.css') ?>">
<link rel="stylesheet" href="<?= base_url('assets/css/destino.css') ?>">
