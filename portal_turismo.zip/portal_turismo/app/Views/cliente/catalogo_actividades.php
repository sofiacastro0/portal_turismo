<!DOCTYPE html>
<html lang="es" data-bs-theme="light">
<head>
    <title>Actividades | Turismo Mar del Plata</title>
    <?= view('layout/bootstrap_head') ?>
</head>
<body class="bg-body-tertiary">
    <?= view('layout/navbar') ?>
    <main class="cliente-main">
        <header class="cliente-heading">
            <div>
                <p class="cliente-kicker"><?= session()->get('rol') === 'admin' ? 'Vista de administrador' : 'Hola, ' . esc(session()->get('nombre')) ?></p>
                <h1>Actividades para disfrutar</h1>
                <p>Encontrá experiencias y planes para descubrir Mar del Plata.</p>
            </div>
            <nav class="cliente-tabs" aria-label="Secciones del catálogo">
                <a class="active" aria-current="page" href="<?= site_url('cliente/actividades') ?>">Actividades</a>
                <a href="<?= site_url('cliente/alojamientos') ?>">Alojamientos</a>
                <?php if (session()->get('rol') === 'cliente'): ?>
                    <a href="<?= site_url('cliente/historial') ?>">Mis reservas</a>
                <?php endif; ?>
            </nav>
        </header>

        <?php if ($error = session()->getFlashdata('error')): ?>
            <div class="alert alert-danger cliente-alert" role="alert"><?= esc($error) ?></div>
        <?php endif; ?>

        <?php if (!empty($publicaciones)): ?>
            <section class="cliente-grid" aria-label="Actividades disponibles">
                <?php foreach ($publicaciones as $pub): ?>
                    <article class="cliente-card">
                        <div class="cliente-card-image">
                            <?php if (!empty($pub['imagen'])): ?>
                                <img src="<?= base_url('uploads/' . rawurlencode($pub['imagen'])) ?>" alt="<?= esc($pub['nombre']) ?>" loading="lazy">
                            <?php endif; ?>
                            <span class="cliente-card-tag">Actividad</span>
                        </div>
                        <div class="cliente-card-body">
                            <h2><?= esc($pub['nombre']) ?></h2>
                            <p class="cliente-card-location"><span aria-hidden="true">⌖</span><?= esc($pub['ubicacion']) ?></p>
                            <div class="cliente-card-facts">
                                <div class="cliente-card-fact"><small>Precio</small><strong>$<?= esc(number_format((float) $pub['precio'], 2, ',', '.')) ?></strong></div>
                                <div class="cliente-card-fact"><small>Disponibilidad</small><strong><?= (int) $pub['cupo_disponible'] > 0 ? esc($pub['cupo_disponible']) . ' cupos' : 'Agotado' ?></strong></div>
                            </div>
                            <div class="cliente-card-badges">
                                <?php if ($pub['cupo_disponible'] == 0): ?>
                                    <span class="badge text-bg-danger">Sin cupo</span>
                                <?php elseif ($pub['cupo_disponible'] <= 5): ?>
                                    <span class="badge text-bg-warning">Últimos cupos</span>
                                <?php endif; ?>
                                <?php if (($pub['temporada_recomendada'] ?? '') === $temporada_actual || ($pub['temporada_recomendada'] ?? '') === 'todas'): ?>
                                    <span class="badge text-bg-success">Ideal esta temporada</span>
                                <?php endif; ?>
                                <?php if ($pub['reservas_totales'] > 10): ?>
                                    <span class="badge text-bg-primary">Más elegida</span>
                                <?php endif; ?>
                            </div>
                            <a class="cliente-card-cta" href="<?= site_url('cliente/detalle/' . (int) $pub['id_publicacion']) ?>">
                                <?= session()->get('rol') === 'admin' ? 'Ver detalle' : 'Ver y reservar' ?><span aria-hidden="true">→</span>
                            </a>
                        </div>
                    </article>
                <?php endforeach; ?>
            </section>
        <?php else: ?>
            <div class="cliente-empty"><strong>Todavía no hay actividades cargadas.</strong>Volvé pronto para descubrir nuevas propuestas.</div>
        <?php endif; ?>
    </main>
    <?= view('layout/bootstrap_script') ?>
</body>
</html>
