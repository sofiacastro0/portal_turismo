<!DOCTYPE html>
<html lang="es" data-bs-theme="light">
<head>
    <title>Mis reservas | Turismo Mar del Plata</title>
    <?= view('layout/bootstrap_head') ?>
</head>
<body class="bg-body-tertiary">
    <?= view('layout/navbar') ?>
    <main class="container py-4 py-lg-5">
        <?php if ($mensaje = session()->getFlashdata('mensaje')): ?>
            <div class="alert alert-success" role="status"><?= esc($mensaje) ?></div>
        <?php endif; ?>

        <header class="d-flex flex-column flex-lg-row align-items-lg-end justify-content-between gap-3 mb-4">
            <div>
                <p class="text-uppercase text-primary small fw-bold mb-1">Tu cuenta</p>
                <h1 class="display-6 fw-bold">Mis reservas</h1>
                <p class="text-body-secondary mb-0">Acá encontrás el resumen de tus actividades y alojamientos.</p>
            </div>
            <nav class="nav nav-pills bg-body-secondary rounded p-2" aria-label="Secciones del catálogo">
                <a class="nav-link" href="<?= site_url('cliente/actividades') ?>">Actividades</a>
                <a class="nav-link" href="<?= site_url('cliente/alojamientos') ?>">Alojamientos</a>
                <a class="nav-link active" aria-current="page" href="<?= site_url('cliente/historial') ?>">Mis reservas</a>
            </nav>
        </header>

        <div class="table-responsive card border-0 shadow-sm rounded-4">
            <table class="table table-striped table-hover align-middle mb-0">
                <thead>
                    <tr>
                        <th scope="col">Actividad o alojamiento</th>
                        <th scope="col">Fecha de reserva</th>
                        <th scope="col">Cupos</th>
                        <th scope="col">Costo total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($reservas)): ?>
                        <?php foreach ($reservas as $res): ?>
                            <tr>
                                <td><strong><?= esc($res['nombre']) ?></strong></td>
                                <td><?= esc(date('d/m/Y · H:i', strtotime($res['fecha_reserva']))) ?></td>
                                <td><?= esc($res['cantidad_cupos']) ?></td>
                                <td class="fw-semibold">$<?= esc(number_format($res['cantidad_cupos'] * $res['precio'], 2, ',', '.')) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="4" class="text-center p-5"><strong class="d-block">Todavía no hiciste reservas</strong>Cuando reserves una propuesta, vas a encontrarla acá.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>
    <?= view('layout/bootstrap_script') ?>
</body>
</html>