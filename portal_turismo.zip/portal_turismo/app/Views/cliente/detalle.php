<!DOCTYPE html>
<html lang="es" data-bs-theme="light">
<head>
    <title><?= esc($pub['nombre']) ?> | Turismo Mar del Plata</title>
    <?= view('layout/bootstrap_head') ?>
</head>
<body class="bg-body-tertiary">
    <?= view('layout/navbar') ?>
    <main class="cliente-main">
        <?php if ($error = session()->getFlashdata('error')): ?>
            <div class="alert alert-danger" role="alert"><?= esc($error) ?></div>
        <?php endif; ?>

        <a class="detalle-back" href="<?= site_url($pub['tipo'] === 'alojamiento' ? 'cliente/alojamientos' : 'cliente/actividades') ?>"><span aria-hidden="true">←</span> Volver al catálogo</a>

        <article class="detalle-layout">
            <div class="detalle-media">
                <?php if (!empty($pub['imagen'])): ?>
                    <img src="<?= base_url('uploads/' . rawurlencode($pub['imagen'])) ?>" alt="<?= esc($pub['nombre']) ?>">
                <?php endif; ?>
                <span class="detalle-type"><?= esc($pub['tipo']) ?></span>
            </div>

            <div class="detalle-info">
                <p class="cliente-kicker">Conocé esta propuesta</p>
                <h1><?= esc($pub['nombre']) ?></h1>
                <p class="detalle-ubicacion"><span aria-hidden="true">⌖</span><?= esc($pub['ubicacion']) ?></p>

                <div class="detalle-resumen">
                    <div class="detalle-dato">
                        <small>Disponibilidad</small>
                        <strong><?= (int) $pub['cupo_disponible'] > 0 ? esc($pub['cupo_disponible']) . ' cupos' : 'Sin cupos' ?></strong>
                    </div>
                    <div class="detalle-dato">
                        <small>Recomendación</small>
                        <strong><?= esc(ucfirst($pub['temporada_recomendada'] ?: 'Todo el año')) ?></strong>
                    </div>
                </div>

                <p class="detalle-precio"><small>Precio <?= $pub['tipo'] === 'alojamiento' ? 'por noche' : 'por persona' ?></small><br><strong>$<?= esc(number_format((float) $pub['precio'], 2, ',', '.')) ?></strong></p>

                <?php if (session()->get('rol') === 'admin'): ?>
                    <div class="detalle-admin-note" role="status">Vista de administrador: podés consultar esta propuesta, pero las reservas están deshabilitadas.</div>
                <?php elseif ((int) $pub['cupo_disponible'] > 0): ?>
                    <form class="detalle-form" action="<?= site_url('cliente/reservar/' . (int) $pub['id_publicacion']) ?>" method="post">
                        <?= csrf_field() ?>
                        <label for="cantidad">¿Cuántos cupos querés reservar?</label>
                        <input type="number" id="cantidad" name="cantidad_cupos" min="1" max="<?= (int) $pub['cupo_disponible'] ?>" value="1" required>
                        <button class="detalle-submit" type="submit">Confirmar reserva <span aria-hidden="true">→</span></button>
                    </form>
                <?php else: ?>
                    <p class="detalle-unavailable">En este momento no quedan cupos disponibles para esta propuesta.</p>
                <?php endif; ?>
            </div>
        </article>
    </main>
    <?= view('layout/bootstrap_script') ?>
</body>
</html>
