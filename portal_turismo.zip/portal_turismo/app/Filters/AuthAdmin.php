<?php
namespace App\Filters;

use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use CodeIgniter\Filters\FilterInterface;

class AuthAdmin implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        if (! session()->get('logeado')) {
            return redirect()->to('/login');
        }

        if (session()->get('rol') === 'cliente') {
            return redirect()->to('/cliente/actividades');
        }

        if (session()->get('rol') !== 'admin') {
            session()->destroy();
            return redirect()->to('/login');
        }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
    }
}
