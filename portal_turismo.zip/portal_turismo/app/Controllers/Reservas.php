<?php
namespace App\Controllers;

use App\Models\PublicacionModel;
use App\Models\ReservaModel;

class Reservas extends BaseController
{
    public function crear($id_publicacion)
    {
        if (session()->get('rol') !== 'cliente') {
            return redirect()->to('/cliente/actividades')->with('error', 'Como administrador podés consultar las propuestas, pero no realizar reservas.');
        }

        $cantidad = filter_var($this->request->getPost('cantidad_cupos'), FILTER_VALIDATE_INT);
        $id_usuario = session()->get('id_usuario');

        if ($cantidad === false || $cantidad < 1) {
            return redirect()->back()->with('error', 'Ingresá una cantidad válida de cupos.');
        }

        $pubModel = new PublicacionModel();
        $reservaModel = new ReservaModel();

        $publicacion = $pubModel->find($id_publicacion);

        if (!$publicacion) {
            return redirect()->to('/cliente/actividades')->with('error', 'La publicación ya no está disponible.');
        }

        $db = \Config\Database::connect();
        $db->transBegin();

        $db->table('publicaciones')
            ->where('id_publicacion', (int) $id_publicacion)
            ->where('cupo_disponible >=', $cantidad)
            ->set('cupo_disponible', 'cupo_disponible - ' . $cantidad, false)
            ->set('reservas_totales', 'reservas_totales + ' . $cantidad, false)
            ->update();

        if ($db->affectedRows() !== 1) {
            $db->transRollback();
            return redirect()->back()->with('error', 'No hay cupos suficientes para tu solicitud.');
        }

        $guardada = $reservaModel->insert([
            'id_usuario'     => $id_usuario,
            'id_publicacion' => (int) $id_publicacion,
            'cantidad_cupos' => $cantidad,
            'fecha_reserva'  => date('Y-m-d H:i:s'),
        ]);

        if ($guardada === false || $db->transStatus() === false) {
            $db->transRollback();
            return redirect()->back()->with('error', 'Hubo un error al procesar la reserva. Intentá nuevamente.');
        }

        $db->transCommit();
        return redirect()->to('/cliente/historial')->with('mensaje', '¡Reserva confirmada con éxito!');
    }

    public function historial()
    {

        $id_usuario = session()->get('id_usuario');
        $db = \Config\Database::connect();
        
        $builder = $db->table('reservas');
        $builder->select('reservas.*, publicaciones.nombre, publicaciones.precio');
        $builder->join('publicaciones', 'publicaciones.id_publicacion = reservas.id_publicacion');
        $builder->where('reservas.id_usuario', $id_usuario);
        $builder->orderBy('reservas.fecha_reserva', 'DESC'); 
        
        $datos['reservas'] = $builder->get()->getResultArray();

        return view('cliente/historial', $datos);
    }
}
