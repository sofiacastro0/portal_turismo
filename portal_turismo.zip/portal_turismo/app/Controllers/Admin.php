<?php
namespace App\Controllers;
use App\Libraries\PaginaImagenes;
use App\Models\PublicacionModel;
use App\Models\CategoriaModel; 

class Admin extends BaseController
{
    public function index()
    {
        $modelo = new PublicacionModel();
        
        $datos = [
            'publicaciones' => $modelo->findAll()
        ];
        
        return view('admin/lista_publicaciones', $datos);
    }

    public function crear()
    {
        $modeloCat = new CategoriaModel();
        $datos['categorias'] = $modeloCat->findAll();
        
        return view('admin/abm_publicaciones', $datos);
    }

    public function guardar()
    {
        if (! $this->validarPublicacion()) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        if (! $this->validate(['imagen' => 'uploaded[imagen]|is_image[imagen]|max_size[imagen,4096]'])) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $modelo = new PublicacionModel();
        $archivo = $this->request->getFile('imagen');
        $nombreImagen = $archivo->getRandomName();
        if (! $archivo->move(FCPATH . 'uploads', $nombreImagen)) {
            return redirect()->back()->withInput()->with('error', 'No se pudo guardar la imagen. Revisá los permisos de public/uploads.');
        }

        if ($modelo->insert($this->datosPublicacion($nombreImagen)) === false) {
            @unlink(FCPATH . 'uploads/' . $nombreImagen);
            return redirect()->back()->withInput()->with('error', 'No se pudo guardar la publicación. Revisá los datos e intentá nuevamente.');
        }
        return redirect()->to(base_url('admin/publicaciones'));
    }

    public function eliminar($id)
    {
        $modelo = new PublicacionModel();
        $publicacion = $modelo->find($id);
        
        if ($publicacion) {
            if ($modelo->delete($id)) {
                $rutaImagen = FCPATH . 'uploads/' . basename($publicacion['imagen']);
                if (is_file($rutaImagen)) {
                    unlink($rutaImagen);
                }
            }
        }
        
        return redirect()->to(base_url('admin/publicaciones'));
    }

    public function editar($id)
    {
        $modeloPub = new PublicacionModel();
        $modeloCat = new CategoriaModel();

        $datos['publicacion'] = $modeloPub->find($id);
        if (! $datos['publicacion']) {
            return redirect()->to(base_url('admin/publicaciones'))->with('error', 'La publicación solicitada no existe.');
        }
        $datos['categorias'] = $modeloCat->findAll();

        return view('admin/abm_publicaciones', $datos);
    }

    public function actualizar($id)
    {
        $modelo = new PublicacionModel();
        $publicacionAnterior = $modelo->find($id); 
        if (! $publicacionAnterior) {
            return redirect()->to(base_url('admin/publicaciones'))->with('error', 'La publicación solicitada no existe.');
        }

        if (! $this->validarPublicacion()) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $archivo = $this->request->getFile('imagen');
        $nombreImagen = $publicacionAnterior['imagen'];
        $imagenNueva = false;

        if ($archivo && $archivo->getError() !== UPLOAD_ERR_NO_FILE) {
            if (! $this->validate(['imagen' => 'uploaded[imagen]|is_image[imagen]|max_size[imagen,4096]'])) {
                return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
            }
            if (! $archivo->isValid() || $archivo->hasMoved()) {
                return redirect()->back()->withInput()->with('error', 'La imagen no se pudo cargar correctamente.');
            }
            $nombreImagen = $archivo->getRandomName();
            if (! $archivo->move(FCPATH . 'uploads', $nombreImagen)) {
                return redirect()->back()->withInput()->with('error', 'No se pudo guardar la imagen. Revisá los permisos de public/uploads.');
            }
            $imagenNueva = true;
        }

        if (! $modelo->update($id, $this->datosPublicacion($nombreImagen))) {
            if ($imagenNueva) {
                @unlink(FCPATH . 'uploads/' . $nombreImagen);
            }
            return redirect()->back()->withInput()->with('error', 'No se pudo actualizar la publicación.');
        }

        if ($imagenNueva) {
            $rutaVieja = FCPATH . 'uploads/' . basename($publicacionAnterior['imagen']);
            if (is_file($rutaVieja)) {
                unlink($rutaVieja);
            }
        }
        return redirect()->to(base_url('admin/publicaciones'));
    }

    public function reservas()
    {

        $db = \Config\Database::connect();
        
        $builder = $db->table('reservas');
        $builder->select('reservas.*, publicaciones.nombre AS nombre_publicacion, publicaciones.precio, usuarios.nombre AS nombre_usuario, usuarios.email');
        $builder->join('publicaciones', 'publicaciones.id_publicacion = reservas.id_publicacion');
        $builder->join('usuarios', 'usuarios.id_usuario = reservas.id_usuario');
        $builder->orderBy('reservas.fecha_reserva', 'DESC'); // Las más nuevas primero
        
        $datos['reservas'] = $builder->get()->getResultArray();

        return view('admin/lista_reservas', $datos);
    }

    public function usuarios()
    {
        $modelo = new \App\Models\UsuarioModel();
        
        $datos['usuarios'] = $modelo->findAll();

        return view('admin/lista_usuarios', $datos);
    }

    public function imagenesPaginas()
    {
        return view('admin/imagenes_paginas', [
            'paginas' => PaginaImagenes::PAGINAS,
            'imagenes' => PaginaImagenes::obtenerTodas(),
        ]);
    }

    public function guardarImagenPagina($pagina)
    {
        if (! array_key_exists($pagina, PaginaImagenes::PAGINAS)) {
            return redirect()->to(site_url('admin/imagenes'))->with('error', 'La página seleccionada no es válida.');
        }

        $mensajes = [
            'imagen.uploaded' => 'Seleccioná una imagen para subir.',
            'imagen.is_image' => 'El archivo debe ser una imagen válida.',
            'imagen.max_size' => 'La imagen no puede superar los 4 MB.',
        ];

        if (! $this->validate(['imagen' => 'uploaded[imagen]|is_image[imagen]|max_size[imagen,4096]'], $mensajes)) {
            return redirect()->to(site_url('admin/imagenes'))
                ->with('error', $this->validator->getError('imagen') ?? 'No se pudo validar la imagen.');
        }

        $archivo = $this->request->getFile('imagen');
        if (! $archivo->isValid() || $archivo->hasMoved()) {
            return redirect()->to(site_url('admin/imagenes'))->with('error', 'La imagen no se pudo cargar correctamente.');
        }

        $directorio = PaginaImagenes::directorioPublico();
        if (! is_dir($directorio) && ! mkdir($directorio, 0755, true) && ! is_dir($directorio)) {
            return redirect()->to(site_url('admin/imagenes'))->with('error', 'No se pudo crear la carpeta para guardar las imágenes.');
        }

        $imagenes = PaginaImagenes::obtenerTodas();
        $anterior = $imagenes[$pagina] ?? null;
        $nuevoNombre = $pagina . '_' . $archivo->getRandomName();

        if (! $archivo->move($directorio, $nuevoNombre)) {
            return redirect()->to(site_url('admin/imagenes'))->with('error', 'No se pudo guardar la imagen. Revisá los permisos de la carpeta public/uploads.');
        }

        $imagenes[$pagina] = $nuevoNombre;
        if (! PaginaImagenes::guardarTodas($imagenes)) {
            @unlink($directorio . $nuevoNombre);
            return redirect()->to(site_url('admin/imagenes'))->with('error', 'No se pudo actualizar la imagen de la página.');
        }

        if ($anterior && basename($anterior) === $anterior && is_file($directorio . $anterior)) {
            unlink($directorio . $anterior);
        }

        return redirect()->to(site_url('admin/imagenes'))->with('mensaje', 'La imagen de ' . PaginaImagenes::PAGINAS[$pagina] . ' se actualizó correctamente.');
    }

    public function eliminarUsuario($id)
    {
        $modelo = new \App\Models\UsuarioModel();
        $usuario = $modelo->find($id);

        if (! $usuario) {
            return redirect()->to(site_url('admin/usuarios'))->with('error', 'La cuenta que intentás eliminar ya no existe.');
        }

        if ((int) $id === (int) session()->get('id_usuario')) {
            return redirect()->to(site_url('admin/usuarios'))->with('error', 'No podés eliminar la cuenta con la que tenés iniciada sesión.');
        }

        $db = \Config\Database::connect();
        $db->transBegin();

        $db->table('reservas')->where('id_usuario', $id)->delete();
        $eliminado = $modelo->delete($id);

        if (! $eliminado || $db->transStatus() === false) {
            $db->transRollback();
            return redirect()->to(site_url('admin/usuarios'))->with('error', 'No se pudo eliminar la cuenta. Intentá nuevamente.');
        }

        $db->transCommit();

        return redirect()->to(site_url('admin/usuarios'))->with('mensaje', 'La cuenta y sus reservas asociadas se eliminaron correctamente.');
    }

    private function datosPublicacion($nombreImagen)
    {
        return [
            'nombre'                => $this->request->getPost('nombre'),
            'ubicacion'             => $this->request->getPost('ubicacion'),
            'precio'                => $this->request->getPost('precio'),
            'tipo'                  => $this->request->getPost('tipo'),
            'id_categoria'          => $this->request->getPost('id_categoria'),
            'cupo_disponible'       => $this->request->getPost('cupo_disponible'),
            'temporada_recomendada' => $this->request->getPost('temporada_recomendada'),
            'imagen'                => $nombreImagen
        ];
    }

    private function validarPublicacion(): bool
    {
        $reglas = [
            'nombre' => 'required|min_length[2]|max_length[150]',
            'ubicacion' => 'required|max_length[150]',
            'precio' => 'required|numeric|greater_than_equal_to[0]',
            'tipo' => 'required|in_list[actividad,alojamiento]',
            'id_categoria' => 'required|is_natural_no_zero',
            'cupo_disponible' => 'required|is_natural',
            'temporada_recomendada' => 'required|in_list[todas,verano,otoño,invierno,primavera]',
        ];

        return $this->validate($reglas);
    }
}
