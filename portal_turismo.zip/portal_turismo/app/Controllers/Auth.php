<?php
namespace App\Controllers;
use App\Models\UsuarioModel;

class Auth extends BaseController
{
    public function registro()
    {
        if (session()->get('logeado')) {
            return redirect()->to(session()->get('rol') === 'admin' ? '/admin/publicaciones' : '/cliente/actividades');
        }

        return view('auth/registro');
    }

    public function procesarRegistro()
    {
        $modelo = new UsuarioModel();
        $email = strtolower(trim((string) $this->request->getPost('email')));

        if ($email !== '' && $modelo->where('email', $email)->first()) {
            return redirect()->back()->withInput()->with('errors', [
                'email' => 'Ya existe una cuenta con este correo electrónico.',
            ]);
        }

        $reglas = [
            'nombre' => 'required|min_length[2]|max_length[100]',
            'email' => 'required|valid_email|max_length[254]',
            'password' => 'required|min_length[8]|max_length[255]',
        ];
        $mensajes = [
            'nombre.required' => 'Ingresá tu nombre completo.',
            'nombre.min_length' => 'El nombre debe tener al menos 2 caracteres.',
            'nombre.max_length' => 'El nombre no puede superar los 100 caracteres.',
            'email.required' => 'Ingresá tu correo electrónico.',
            'email.valid_email' => 'Ingresá un correo electrónico válido.',
            'email.max_length' => 'El correo no puede superar los 254 caracteres.',
            'password.required' => 'Ingresá una contraseña.',
            'password.min_length' => 'La contraseña debe tener al menos 8 caracteres.',
            'password.max_length' => 'La contraseña no puede superar los 255 caracteres.',
        ];

        if (! $this->validate($reglas, $mensajes)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $guardado = $modelo->insert([
            'nombre'   => trim((string) $this->request->getPost('nombre')),
            'email'    => $email,
            'password' => password_hash((string) $this->request->getPost('password'), PASSWORD_DEFAULT),
            'rol'      => 'cliente'
        ]);

        if ($guardado === false) {
            return redirect()->back()->withInput()->with('error', 'No se pudo crear la cuenta. Revisá los datos e intentá nuevamente.');
        }

        return redirect()->to('/login')->with('mensaje', 'Tu cuenta se creó correctamente. Ya podés iniciar sesión.');
    }

    public function login()
    {
        if (session()->get('logeado')) {
            return redirect()->to(session()->get('rol') === 'admin' ? '/admin/publicaciones' : '/cliente/actividades');
        }

        return view('auth/login');
    }

    public function procesarLogin()
    {
        $reglas = [
            'email' => 'required|valid_email|max_length[254]',
            'password' => 'required|max_length[255]',
        ];
        $mensajes = [
            'email.required' => 'Ingresá tu correo electrónico.',
            'email.valid_email' => 'Ingresá un correo electrónico válido.',
            'email.max_length' => 'El correo no puede superar los 254 caracteres.',
            'password.required' => 'Ingresá tu contraseña.',
            'password.max_length' => 'La contraseña es demasiado larga.',
        ];

        if (! $this->validate($reglas, $mensajes)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $email = strtolower(trim((string) $this->request->getPost('email')));
        $password_ingresada = (string) $this->request->getPost('password');

        $modelo = new UsuarioModel();

        $usuario = $modelo->where('email', $email)->first();

        if (! $usuario) {
            return redirect()->back()->withInput()->with('errors', [
                'email' => 'No existe una cuenta con este correo electrónico.',
            ]);
        }

        if (in_array($usuario['rol'], ['admin', 'cliente'], true) && password_verify($password_ingresada, $usuario['password'])) {
            
            session()->regenerate(true);
            session()->set([
                'id_usuario' => $usuario['id_usuario'],
                'nombre'     => $usuario['nombre'],
                'rol'        => $usuario['rol'],
                'logeado'    => true
            ]);

            return redirect()->to('/');
        }

        return redirect()->back()->withInput()->with('errors', [
            'password' => 'La contraseña no es correcta.',
        ]);
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('/');
    }
}
