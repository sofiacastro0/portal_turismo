<?php
namespace App\Controllers;

use App\Models\PublicacionModel;
use App\Libraries\PaginaImagenes;

class Home extends BaseController
{
    public function index()
    {
        $modelo = new PublicacionModel();
        $publicaciones = $modelo
            ->whereIn('tipo', ['actividad', 'alojamiento'])
            ->orderBy('reservas_totales', 'DESC')
            ->findAll(6);

        return view('public/home', ['publicaciones' => $publicaciones]);
    }

    public function historia()
    {
        return $this->vistaInformativa('historia');
    }

    public function gastronomia()
    {
        return $this->vistaInformativa('gastronomia');
    }

    public function geografia()
    {
        return $this->vistaInformativa('geografia');
    }

    public function transporte()
    {
        return view('public/transporte');
    }

    private function vistaInformativa(string $pagina)
    {
        $imagenes = PaginaImagenes::obtenerTodas();

        return view('public/' . $pagina, [
            'imagenFondo' => $imagenes[$pagina] ?? null,
        ]);
    }
}
