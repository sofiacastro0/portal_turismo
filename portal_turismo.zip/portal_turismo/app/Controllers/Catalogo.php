<?php
namespace App\Controllers;

use App\Models\PublicacionModel;

class Catalogo extends BaseController
{
    public function actividades()
    {
        return $this->mostrarCatalogo('actividad', 'cliente/catalogo_actividades');
    }

    public function alojamientos()
    {
        return $this->mostrarCatalogo('alojamiento', 'cliente/catalogo_alojamientos');
    }

    public function detalle($id)
    {

        $modelo = new PublicacionModel();
        $datos['pub'] = $modelo->find($id);

        if (!$datos['pub']) {
            return redirect()->to('/cliente/actividades'); 
        }

        return view('cliente/detalle', $datos);
    }

    private function mostrarCatalogo($tipo, $vista)
    {
        $modelo = new PublicacionModel();

        $datos = [
            'publicaciones' => $modelo->where('tipo', $tipo)->findAll(),
            'temporada_actual' => $this->obtenerTemporadaActual()
        ];

        return view($vista, $datos);
    }

    private function obtenerTemporadaActual()
    {
        $mes = (int) date('n');
        $dia = (int) date('j');

        if (($mes == 3 && $dia >= 21) || $mes == 4 || $mes == 5 || ($mes == 6 && $dia < 21)) {
            return 'otoño';
        } elseif (($mes == 6 && $dia >= 21) || $mes == 7 || $mes == 8 || ($mes == 9 && $dia < 21)) {
            return 'invierno';
        } elseif (($mes == 9 && $dia >= 21) || $mes == 10 || $mes == 11 || ($mes == 12 && $dia < 21)) {
            return 'primavera';
        } else {
            return 'verano';
        }
    }
}
