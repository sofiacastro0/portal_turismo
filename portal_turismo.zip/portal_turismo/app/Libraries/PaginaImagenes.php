<?php
namespace App\Libraries;

class PaginaImagenes
{
    public const PAGINAS = [
        'historia' => 'Historia',
        'geografia' => 'Geografía',
        'gastronomia' => 'Gastronomía',
    ];

    private const ARCHIVO_CONFIG = WRITEPATH . 'pagina_imagenes.json';
    private const DIRECTORIO_PUBLICO = FCPATH . 'uploads/paginas/';

    public static function obtenerTodas(): array
    {
        if (! is_file(self::ARCHIVO_CONFIG)) {
            return [];
        }

        $datos = json_decode((string) file_get_contents(self::ARCHIVO_CONFIG), true);
        if (! is_array($datos)) {
            return [];
        }

        $imagenes = [];
        foreach (self::PAGINAS as $pagina => $titulo) {
            $nombre = $datos[$pagina] ?? null;
            if (! is_string($nombre) || basename($nombre) !== $nombre) {
                continue;
            }

            if (preg_match('/^[a-z]+_[a-zA-Z0-9_-]+\.(?:jpg|jpeg|png|webp|gif)$/i', $nombre)
                && is_file(self::DIRECTORIO_PUBLICO . $nombre)) {
                $imagenes[$pagina] = $nombre;
            }
        }

        return $imagenes;
    }

    public static function guardarTodas(array $imagenes): bool
    {
        $json = json_encode($imagenes, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        if ($json === false) {
            return false;
        }

        return file_put_contents(self::ARCHIVO_CONFIG, $json, LOCK_EX) !== false;
    }

    public static function directorioPublico(): string
    {
        return self::DIRECTORIO_PUBLICO;
    }
}
